#Installation Step

npm install

#Running the App

npm start & gulp

The app should automatically open up in default browser